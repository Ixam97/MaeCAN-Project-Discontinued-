<?php 
	$page = $_GET['page'];
	$side = $_GET['side']; 
?>

<!DOCTYPE html>
<html id="root" style="font-size: 10px; background-color: #ccc;">
	<head>
		<title>Integrator</title>
		<link rel="stylesheet" type="text/css" href="styles/nexus7.css?<?php echo time(); ?>">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<noscript>Javascript ist erforderlich!</noscript>

	</head>
	<body>

		<?php include 'php/'.$page.'.php'; ?>

		<script type="text/javascript" src="js/main.js?41452857"></script>
	</body>
</html>
