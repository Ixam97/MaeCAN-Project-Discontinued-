<?php 
	exec('python/stopgo go');
?>