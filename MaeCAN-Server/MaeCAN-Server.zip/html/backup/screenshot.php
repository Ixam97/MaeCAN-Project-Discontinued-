
<?php 
  exec('echo "" > screenshot');
?>

<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="refresh" content="2; URL=screenshot.png">
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="main.css">
	<title>Screenshot</title>
</head>
<body>

<div id="wrapper" style="width: auto;">
	<h1>Screenshot wird erstellt...</h1>
</div>

</body>
</html>