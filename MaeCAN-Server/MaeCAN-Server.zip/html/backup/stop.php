<?php 
	exec('python/stopgo stop');
?>