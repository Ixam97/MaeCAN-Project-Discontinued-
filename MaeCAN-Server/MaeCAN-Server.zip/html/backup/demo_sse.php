<?php
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');

$time = date('r');
echo "retry: 1000\n\n";
echo "data: Die Serverzeit ist: {$time}\n\n";
flush();
?>