<?php
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');

	$state = file_get_contents('python/caninformation.txt');
	echo "retry: 100\n\n";
	echo "data: {$state}\n\n";
	flush();
?>