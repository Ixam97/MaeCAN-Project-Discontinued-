<!DOCTYPE html>
<html id="root" style="font-size: 62.5%;">
	<head>
		<title>MäCAN-Webserver</title>
		<link rel="stylesheet" type="text/css" href="styles/rangeslider.custom.css?v=<?=time();?>">
		<link rel="stylesheet" type="text/css" href="styles/main.css?v=<?=time();?>">
		<meta charset="utf-8">

		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/rangeslider.min.js"></script>
		<noscript>Javascript ist erforderlich!</noscript>

	</head>
	<body id="body">
	<div id="dummy">
		<div class="container" style="margin: 0;">
			<div class="containerheader">Direktsteuerung</div>
			<div class="containercontent">
				<div class="subcontainer">
					<div class="locoselect">
						<div class="locoselect_left">
							<div class="radiodiv">
								<input id="radio01" type="radio" name="protocol" checked/>
			  					<label for="radio01"><span></span>Motorola</label>
			  				</div>
			  				<div class="radiodiv">
								<input id="radio02" type="radio" name="protocol"/>
			  					<label for="radio02"><span></span>DCC</label>
			  				</div>
			  			</div>
			  			<div class="locoselect_left">
			  				<div class="textdiv">
				  				<p>Adresse:</p>
								<input id="adress_input" class="textfield" type="text" name="adress" value="1"><br>
							</div>
						</div>
						<div class="locoselect_left">
							<div class="button"><a href="" id="confirm_adress" style="height: 3.3rem; line-height: 3.3rem;">OK</a></div>
						</div>
					</div>
					<div class="controlscontainer">
						
						<div class="slider">
							<input type="range" id="rangeslider01" data-orientation="vertical" min="0" max="1000" value="0" step="1">
							<div class="button" id="change_direction" style="padding: .7rem 0 0 "><a id="changedirection" href="">
								<div id="left" style="display: inline-block; width: 100%;">
									<div style="width: 0; height: 0; border-bottom: 2rem solid transparent; border-top: 2rem solid transparent; border-right: 2rem solid #2FA938; float: left;"></div>
									<div style="width: 0; height: 0; border-bottom: 2rem solid transparent; border-top: 2rem solid transparent; border-left: 2rem solid #dadada; float: right;"></div>
								</div>
								<div id="right" style="width: 100%; display: none">
									<div style="width: 0; height: 0; border-bottom: 2rem solid transparent; border-top: 2rem solid transparent; border-right: 2rem solid #dadada; float: left;"></div>
									<div style="width: 0; height: 0; border-bottom: 2rem solid transparent; border-top: 2rem solid transparent; border-left: 2rem solid #2fa938; float: right;"></div>
								</div>
							</a></div>
						</div>
						<div class="functions">
							<div class="button function"><a href="">F0</a></div>
							<div class="button function"><a href="">F1</a></div>
							<div class="button function"><a href="">F2</a></div>
							<div class="button function"><a href="">F3</a></div>
							<div class="button function"><a href="">F4</a></div>
							<div class="button function"><a href="">F5</a></div>
							<div class="button function"><a href="">F6</a></div>
							<div class="button function" style="margin: 0;"><a href="" onclick="return false;">F7</a></div>
						</div>
						<div class="functions">
							<div class="button function"><a href="">F8</a></div>
							<div class="button function"><a href="">F9</a></div>
							<div class="button function"><a href="">F10</a></div>
							<div class="button function"><a href="">F11</a></div>
							<div class="button function"><a href="">F12</a></div>
							<div class="button function"><a href="">F13</a></div>
							<div class="button function"><a href="">F14</a></div>
							<div class="button function" style="margin: 0;"><a href="">F15</a></div>
						</div>
					</div>
				</div>
				<div class="subcontainer">
				<center>
					<div class="button floatingleft"><a class="stopgobutton" id="stop_button_1" style="color: red;" href="">STOP</a></div>
					<div class="button floatingleft"><a class="stopgobutton" id="go_button_1" style="color: green;" href="">GO</a></div>
				</center>
				</div>
			</div>
		</div>
   
   
		<script type="text/javascript" src="js/main.new.js?v=<?=time();?>"></script>
	</div>
	</body>
</html>
