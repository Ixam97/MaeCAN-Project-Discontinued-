<?php

$state = file_get_contents('../python/caninformation.txt');
echo $state;
	
?>
