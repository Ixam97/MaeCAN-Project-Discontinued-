<!DOCTYPE html>
<html id="root" style="font-size: 62.5%;">
<head>
	<title>MäCAN-Webserver</title>
	<link rel="stylesheet" type="text/css" href="styles/rangeslider.custom.css?v=<?=time();?>">
	<link rel="stylesheet" type="text/css" href="styles/main.css?v=<?=time();?>">
	<meta charset="utf-8">

	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/rangeslider.min.js"></script>
	<script type="text/javascript" src="js/main.js?v=<?=time();?>"></script>
	<noscript>Javascript ist erforderlich!</noscript>

</head>
<body onload="onLoad(); return false;">

	<div id="wrapper">
		<h1>MäCAN-Webserver</h1>
		<!--<img src="maecanlogo.png">*/-->


		<!-- SERVERFUNKTIONEN -->

		<div class="container">
			<div class="containerheader">Serverfuntionen</div>
			<div class="containercontent">
				<div class="subcontainer">
					<div class="button floatingleft"><a href="screenshot.php" target="_blank">Screenshot erstellen</a></div>
					<div class="button floatingleft"><a href="screenshot.png" target="_blank">Letzten Screenshot anzeigen</a></div>
				</div>
			</div>
		</div>


		<!-- CAN-FUNKTIONEN -->

		<div class="container">
			<div class="containerheader">CAN-Funktionen</div>
			<div class="containercontent">
				<div class="subcontainer">
					<div class="button floatingleft"><a class="stopgobutton" id="stopbutton" style="color: red;" href="" onclick="stop(); return false;">STOP</a></div>
					<div class="button floatingleft"><a class="stopgobutton" id="gobutton" style="color: green;" href="" onclick="go(); return false;">GO</a></div>
				</div>
			</div>
		</div>


		<!-- DIREKTSTEUERUNG -->

		<div class="container">
			<div class="containerheader">Direktsteuerung</div>
			<div class="containercontent">
				<div class="subcontainer">
				<div class="locoselect">
					<div class="locoselect_left">
						<div class="radiodiv">
							<input id="radio01" type="radio" name="protocol" checked />
		  					<label for="radio01"><span></span>Motorola</label>
		  				</div>
		  				<div class="radiodiv">
							<input id="radio02" type="radio" name="protocol" />
		  					<label for="radio02"><span></span>DCC</label>
		  				</div>
		  			</div>
		  			<div class="locoselect_left">
		  				<div class="textdiv">
			  				<p>Adresse:</p>
							<input id="adress_input" class="textfield" type="text" name="adress" value="1""><br>
						</div>
					</div>
					<div class="locoselect_left">
						<div class="button"><a href="" id="confirm_adress" style="height: 3.3rem; line-height: 3.3rem;" onclick="updatelocid(); return false;">OK</a></div>
					</div>
				</div>
					<div class="controlscontainer">
						
						<div class="slider">
							<input type="range" id="rangeslider-0" data-orientation="vertical" min="0" max="1000" value="0" step="5">
							<div class="button" id="changedirection" style="padding: .7rem 0 0 "><a id="changedirection" href="" onclick="changeDirection(); return false;">
								<div id="left" style="display: inline-block; width: 100%;">
									<div style="width: 0; height: 0; border-bottom: 2rem solid transparent; border-top: 2rem solid transparent; border-right: 2rem solid #2FA938; float: left;"></div>
									<div style="width: 0; height: 0; border-bottom: 2rem solid transparent; border-top: 2rem solid transparent; border-left: 2rem solid #dadada; float: right;"></div>
								</div>
								<div id="right" style="width: 100%; display: none">
									<div style="width: 0; height: 0; border-bottom: 2rem solid transparent; border-top: 2rem solid transparent; border-right: 2rem solid #dadada; float: left;"></div>
									<div style="width: 0; height: 0; border-bottom: 2rem solid transparent; border-top: 2rem solid transparent; border-left: 2rem solid #2fa938; float: right;"></div>
								</div>
							</a></div>
						</div>
						<div class="functions">
							<div class="button"><a href="" onclick="return false;">F0</a></div>
							<div class="button"><a href="" onclick="return false;">F1</a></div>
							<div class="button"><a href="" onclick="return false;">F2</a></div>
							<div class="button"><a href="" onclick="return false;">F3</a></div>
							<div class="button"><a href="" onclick="return false;">F4</a></div>
							<div class="button"><a href="" onclick="return false;">F5</a></div>
							<div class="button"><a href="" onclick="return false;">F6</a></div>
							<div class="button" style="margin: 0;"><a href="" onclick="return false;">F7</a></div>
						</div>
						<div class="functions">
							<div class="button"><a href="" onclick="return false;">F8</a></div>
							<div class="button"><a href="" onclick="return false;">F9</a></div>
							<div class="button"><a href="" onclick="return false;">F10</a></div>
							<div class="button"><a href="" onclick="return false;">F11</a></div>
							<div class="button"><a href="" onclick="return false;">F12</a></div>
							<div class="button"><a href="" onclick="return false;">F13</a></div>
							<div class="button"><a href="" onclick="return false;">F14</a></div>
							<div class="button" style="margin: 0;"><a href="" onclick="return false;">F15</a></div>
						</div>
					</div>
				</div>
				<div class="subcontainer">
					<div class="button floatingleft"><a class="stopgobutton2" id="stopbutton2" style="color: red;" href="" onclick="stop(); return false;">STOP</a></div>
					<div class="button floatingleft"><a class="stopgobutton2" id="gobutton2" style="color: green;" href="" onclick="go(); return false;">GO</a></div>
				</div>
			</div>
		</div>



	</div>
</body>
</html>
