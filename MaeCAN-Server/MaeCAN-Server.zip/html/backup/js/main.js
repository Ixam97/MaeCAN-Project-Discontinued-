var range0;
var range0handle;
var locid;
var radio01;
var adress_input;
var $element;
var lastvalue = 0;
var throttlemanager;
var throttlewatcher;
var isThrotteling = false;
var direction = 'left';

function onLoad(){

	displayScreenSize();

	$element = $('input[type="range"]');
	var $handle;
	$element
	.rangeslider({
		polyfill: false,
		onInit: function() {
			$handle = $('.rangeslider__handle', this.$range);
			$handle[0].textContent = Math.ceil(this.value / 10);
		},
		onSlideEnd: function(){
			throttle(range0.value);
			clearInterval(throttlemanager);
			isThrotteling = false;
			setThrottleWatcher();
		}
	})
	.on('input', function(){ 
		clearInterval(throttlewatcher);
		range0handle.textContent = Math.ceil(range0.value / 10);
		if (!isThrotteling) {
		throttlemanager = setInterval(function(){ throttle(range0.value);}, 100);
		isThrotteling = true;
		}
	});

	//getElement-vars:
	range0 			= document.getElementById('rangeslider-0');
	adress_input 	= document.getElementById('adress_input');
	range0handle	= document.getElementById('js-rangeslider-0').childNodes[1];
	radio01 		= document.getElementById('radio01');

}

var buttonUpdate = new EventSource("buttonupdater.php");

function stop(){ //STOP-Taste
	$.get("stop.php");
}

function go(){ //GO-Taste
	$.get("go.php");
}

function throttle(value){
	if (value != lastvalue) {
		$.get("throttle.php", {locid: locid, value: value});
		lastvalue = value;
	}
}

buttonUpdate.onmessage = function(event) { //Tasten bei wechsel STOP/GO updaten

	if (document.getElementById('stopbutton') != null) {

		if (event.data == '1') {
			document.getElementById('stopbutton').style.backgroundColor = 'white';
			document.getElementById('stopbutton').style.color = '#ff0025';
			document.getElementById('gobutton').style.backgroundColor = '#2FA938';
			document.getElementById('gobutton').style.color = 'white';
		}else if (event.data == '0') {
			document.getElementById('stopbutton').style.backgroundColor = '#ff0025';
			document.getElementById('stopbutton').style.color = 'white';
			document.getElementById('gobutton').style.backgroundColor = 'white';
			document.getElementById('gobutton').style.color = '#2FA938';
		}
	}
	if (document.getElementById('stopbutton2') != null) {

		if (event.data == '1') {
			document.getElementById('stopbutton2').style.backgroundColor = 'white';
			document.getElementById('stopbutton2').style.color = '#ff0025';
			document.getElementById('gobutton2').style.backgroundColor = '#2FA938';
			document.getElementById('gobutton2').style.color = 'white';
		}else if (event.data == '0') {
			document.getElementById('stopbutton2').style.backgroundColor = '#ff0025';
			document.getElementById('stopbutton2').style.color = 'white';
			document.getElementById('gobutton2').style.backgroundColor = 'white';
			document.getElementById('gobutton2').style.color = '#2FA938';
		}
	}
}

function displayScreenSize(){ //Elementgröße in anhängigkeit der Bildschirmauflösung ändern
	var factor;
	var displayScreenWidth = window.screen.width;
	var displayScreenHeight = window.screen.height;
	if (displayScreenWidth < 400) {
		factor = 156.25;
	}else if (displayScreenWidth < 700) {
		factor = 125;
	}else{
		factor = 62.5;
	}
	document.getElementById('root').style.fontSize = factor + '%';
}

function viewportScreenSize(){

}

function setRangeSlider(value){
	range0.value = value;
	$element.rangeslider('update', true);
	range0handle.textContent = Math.ceil(range0.value / 10);
}

function updatelocid(){
	var adrs = parseInt(adress_input.value, 10);
	var locid_base;
	if (radio01.checked) /*Motorola?*/ {
		locid_base = 0;
	}else{
		locid_base = 0xc000;
	}
	locid = locid_base + adrs;
	//document.getElementById('confirm_adress').style.display = 'none';

	clearInterval(throttlewatcher);

	$.get("php/getSpeed.php", {locid: locid}, function(data){
		setRangeSlider(data);
	})

	setThrottleWatcher();

}

function confirmAdress(){
	//document.getElementById('confirm_adress').style.display = 'block';
}

function changeDirection(){
	setRangeSlider(0);
	var left = document.getElementById('left');
	var right = document.getElementById('right');
	if (direction == 'left') {
		left.style.display = 'none';
		right.style.display = 'inline-block';
		direction = 'right';
	}else{
		left.style.display = 'inline-block';
		right.style.display = 'none';
		direction = 'left';
	}
}

function setThrottleWatcher(){
	throttlewatcher = setInterval(function(){
		$.get("php/getSpeed.php", {locid: locid}, function(data){
			setRangeSlider(data);
			lastvalue = data;
		})
	}, 500);
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}