var throttle_slider = $('input[type="range"]');
var throttle_slider_handle;
var throttle_sliding = false;
var speedupdate = false;

var timer;
var throttle_watcher;
var throttle_manager;
var old_speed;

//Wichtige Elemente:
var stop_button_1 = document.getElementById('stop_button_1');
var go_button_1 = document.getElementById('go_button_1');
var function_buttons = document.getElementsByClassName('function');
var change_direction = document.getElementById('change_direction');
var confirm_adress = document.getElementById('confirm_adress');
var adress_input = document.getElementById('adress_input');
var motorola = document.getElementById('radio01');
var dcc = document.getElementById('radio02');
var rangeslider01 = document.getElementById('rangeslider01');

//regelm��ig genutzte Farben:
var cs_red = '#ff0025';
var cs_green = '#2fa938';

//Standard LocID:
var locid = 1;

displayScreenSize();

throttle_slider.rangeslider({
  polyfill: false
});

throttle_slider.on('input', function(){

  // �berpr�ft, ob der Input vom Nutzer oder durch ein regelm��iges Geschwindikeitsupdate ausgel�st wurde
  if (speedupdate){ 
    speedupdate = false;    
  }else{
    // �berpr�ft, ob erster Input und startet entsprechend Throttlemanager
    if (!throttle_sliding) {
      throttle_manager = setInterval(function(){setSpeed(rangeslider01.value);}, 150);
    }

    throttle_sliding = true;
    throttle_slider_handle.textContent = Math.ceil(this.value / 10);

    clearTimeout(timer);
    clearInterval(throttle_watcher);

    timer = setTimeout(function(){
      throttle_sliding = false;
      clearInterval(throttle_manager);
      throttle_watcher = setInterval(getSpeed, 250);
      console.log('restarting');
    },500);

  }
});

throttle_slider_handle = document.getElementById('js-rangeslider-0').childNodes[1];
throttle_slider_handle.textContent = Math.ceil(throttle_slider[0].value / 10);


//allgemeine Funktionen:
function getButtonStatus(){
  $.get("php/buttonUpdater.php", {}, function(data){
    if (data == '0'){
      stop_button_1.style.backgroundColor = cs_red;
      go_button_1.style.backgroundColor = 'white';
      stop_button_1.style.color = 'white';
      go_button_1.style.color = cs_green;
    }else if (data == '1'){
      stop_button_1.style.backgroundColor = 'white';
      go_button_1.style.backgroundColor = cs_green;
      stop_button_1.style.color = cs_red;
      go_button_1.style.color = 'white';
    }
  });
}

//Geschwindigkeit einer LocID anfordern:
function getSpeed(){ 
  $.get("php/getSpeed.php", {locid: locid}, function(data){
    if (data == 'error') {
      console.log('speederror');
    }else if (data != rangeslider01.value) {
      speedupdate = true;
      old_speed = data;
      console.log('getting speed...');
      throttle_slider.val(data).change();
      throttle_slider_handle.textContent = Math.ceil(data / 10);
    }
  });
}

//Geschwindigkeit der aktuellen LocID setzen:
function setSpeed(value){
  if (value != old_speed) {
    $.get("php/throttle.php",{locid: locid, value: value});
    console.log('throtteling...');
    old_speed = value;
  }
}

function displayScreenSize(){ //Elementgr��e in anh�ngigkeit der Bildschirmaufl�sung �ndern
  var factor;
  var displayScreenWidth = window.screen.width;
  var displayScreenHeight = window.screen.height;
  if (displayScreenWidth < 400) {
    factor = 156.25;
  }else if (displayScreenWidth < 700) {
    factor = 125;
  }else{
    factor = 62.5;
  }
  document.getElementById('root').style.fontSize = factor + '%';
}

//Intervallfuntionen:
var button_watcher = setInterval(function(){
  getButtonStatus();
}, 250);
console.log('button_watcher gestartet...');

throttle_watcher = setInterval(function() {
  getSpeed();
}, 250);
console.log('throttle_watcher gestartet...');




//onClick-Events f�r Funktionstasten:
for (var i = 0; i < function_buttons.length; i++) (function(i){
  function_buttons[i].onclick = function(){
    console.log('Schalte Funktion ' + i);
    return false;
  }
})(i);

confirm_adress.onclick = function(){
  if (motorola.checked) {
    locid = parseInt(adress_input.value, 10);
  }else if (dcc.checked) {
    locid = 0xc000 + parseInt(adress_input.value, 10);
  }
  getSpeed();
  return false;
};