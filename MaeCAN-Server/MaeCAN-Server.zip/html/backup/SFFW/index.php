<?php

include('core/header.html');

if (!empty($_GET['site'])){

	$site = $_GET['site'];
	$site = basename($site);

	if(!file_exists("areas/$site.html")) $site = 'index';

	include("areas/$site.html");

}else{

	include('areas/index.html');

}



#include('templates/index.html');
include('core/footer.html');












?>