<?php 
	$value = $_GET['value'];
	$function = $_GET['function'];
	$locid = $_GET['locid'];
	exec('../python/function '.$locid.' '.$function.' '.$value);
 ?>