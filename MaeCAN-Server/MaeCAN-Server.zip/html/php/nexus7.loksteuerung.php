<!--
Loksteuerung
By Maximilian Goldschmidt (cc)
Do what ever you want with this, but keep this header!

Last edited: 05.07.2017
-->
<link rel="stylesheet" type="text/css" href="styles/nexus7.slider.css?<?php echo time() ?>">
<div class="throttle" id="throttle_left">
	<div class="slider" style="margin-left: 10px;">
		<div class="button speed" id="speed_left">0 km/h</div>
		<input type="range" id="slider_left" data-orientation="vertical" min="0" max="1000" value="0" step="1">
		<a href=""><div class="button change_direction" id="change_direction_left">
			<div id="left" style="display: none;">
				<div style="width: 0; height: 0; border-bottom: 2rem solid transparent; border-top: 2rem solid transparent; border-right: 2rem solid #2FA938; float: left;"></div>
				<div style="width: 0; height: 0; border-bottom: 2rem solid transparent; border-top: 2rem solid transparent; border-left: 2rem solid #adadad; float: right;"></div>
			</div>
			<div id="right" style="display: inline-block;">
				<div style="width: 0; height: 0; border-bottom: 2rem solid transparent; border-top: 2rem solid transparent; border-right: 2rem solid #adadad; float: left;"></div>
				<div style="width: 0; height: 0; border-bottom: 2rem solid transparent; border-top: 2rem solid transparent; border-left: 2rem solid #2fa938; float: right;"></div>
			</div>
		</div></a>
	</div>
	<div class="functions">
		<div class="f_top">
			<a href=""><div class="button" id="lokliste_toggle_left">Adresse</div></a>
			<div class="button lokliste" id="lokliste_left"><img id="icon_left" src="icons/.png">Lokauswahl</div>
			<div id="lokliste_container_left" class="dropdown">
				<!--LOKLISTE-->
			</div>
			<div class="address" id="address_left"></div>
		</div>
		<div class="f_left">
			<a href=""><div class="button function_left">F0</div></a>
			<a href=""><div class="button function_left">F1</div></a>
			<a href=""><div class="button function_left">F2</div></a>
			<a href=""><div class="button function_left">F3</div></a>
			<a href=""><div class="button function_left">F4</div></a>
			<a href=""><div class="button function_left">F5</div></a>
			<a href=""><div class="button function_left">F6</div></a>
			<a href=""><div class="button function_left">F7</div></a>
		</div>
		<div class="f_left">
			<a href=""><div class="button function_left">F8</div></a>
			<a href=""><div class="button function_left">F9</div></a>
			<a href=""><div class="button function_left">F10</div></a>
			<a href=""><div class="button function_left">F11</div></a>
			<a href=""><div class="button function_left">F12</div></a>
			<a href=""><div class="button function_left">F13</div></a>
			<a href=""><div class="button function_left">F14</div></a>
			<a href=""><div class="button function_left">F15</div></a>
		</div>
	</div>
</div>
<div class="throttle" id="throttle_right">
	<div class="functions">
		<div class="f_top">
			<a href=""><div class="button" id="lokliste_toggle_right">Adresse</div></a>
			<div class="button lokliste" id="lokliste_right"><img id="icon_right" src="icons/.png">Lokauswahl</div>
			<div id="lokliste_container_right" class="dropdown">
				<!--LOKLISTE-->
			</div>
			<div class="address" id="address_right"></div>
		</div>
		<div class="f_right">
			<a href=""><div class="button function_right">F0</div></a>
			<a href=""><div class="button function_right">F1</div></a>
			<a href=""><div class="button function_right">F2</div></a>
			<a href=""><div class="button function_right">F3</div></a>
			<a href=""><div class="button function_right">F4</div></a>
			<a href=""><div class="button function_right">F5</div></a>
			<a href=""><div class="button function_right">F6</div></a>
			<a href=""><div class="button function_right">F7</div></a>
		</div>
		<div class="f_right">
			<a href=""><div class="button function_right">F8</div></a>
			<a href=""><div class="button function_right">F9</div></a>
			<a href=""><div class="button function_right">F10</div></a>
			<a href=""><div class="button function_right">F11</div></a>
			<a href=""><div class="button function_right">F12</div></a>
			<a href=""><div class="button function_right">F13</div></a>
			<a href=""><div class="button function_right">F14</div></a>
			<a href=""><div class="button function_right">F15</div></a>
		</div>
	</div>
	<div class="slider" style="margin-right: 10px;">
		<div class=" button speed" id="speed_right">0 km/h</div>
		<input type="range" id="slider_right" data-orientation="vertical" min="0" max="1000" value="0" step="1">
		<a href=""><div class="button change_direction" id="change_direction_right">
			<div id="left" style="display: none;">
				<div style="width: 0; height: 0; border-bottom: 2rem solid transparent; border-top: 2rem solid transparent; border-right: 2rem solid #2FA938; float: left;"></div>
				<div style="width: 0; height: 0; border-bottom: 2rem solid transparent; border-top: 2rem solid transparent; border-left: 2rem solid #adadad; float: right;"></div>
			</div>
			<div id="right" style="display: inline-block;">
				<div style="width: 0; height: 0; border-bottom: 2rem solid transparent; border-top: 2rem solid transparent; border-right: 2rem solid #adadad; float: left;"></div>
				<div style="width: 0; height: 0; border-bottom: 2rem solid transparent; border-top: 2rem solid transparent; border-left: 2rem solid #2fa938; float: right;"></div>
			</div>
		</div></a>
	</div>	
</div>

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/rangeslider.min.js"></script>
<script type="text/javascript" src="js/websocket.js"></script>

<script type="text/javascript">
	//------------------------------LINKS-------------------------------------//

	var sides = ['left', 'right'];

	var lokliste_toggle = [];
	var lokliste_button = [];
	var lokliste_container = [];
	var lokliste_visible = [];

	var icon_img = [];
	var function_button = [];
	var speed = [];
	var slider = [];

	//---LOKLISTE:
	var names = [];
	var uids = [];
	var icons = [];
	var vmaxes = [];

	var uid = [];
	var name_side = [];
	var tachomax = [];
	var icon = [];



	for (var i = 0; i < sides.length; i++) {
		var side = sides[i];

		lokliste_toggle[side] = document.getElementById(`lokliste_toggle_${side}`);
		lokliste_button[side] = document.getElementById(`lokliste_${side}`);
		lokliste_container[side] = document.getElementById(`lokliste_container_${side}`);
		lokliste_visible[side] = false;

		icon_img[side] = document.getElementById(`icon_${side}`);
		function_button[side] = document.getElementsByClassName(`function_${side}`);
		speed[side] = document.getElementById(`speed_${side}`);
		slider[side] = $(`#slider_${side}`);

		//uid[side] = 0;
	}

	var fn_state = [];
	fn_state['left'] = [];
	fn_state['right'] = [];


	slider['left'].rangeslider({polyfill: false});
	slider['right'].rangeslider({polyfill: false});

	slider['left'].on('input', function(){
		speed['left'].textContent = `${Math.ceil((this.value / 10) * (tachomax['left'] / 100))} km/h`;
	});

	slider['right'].on('input', function(){
		speed['right'].textContent = `${Math.ceil((this.value / 10) * (tachomax['right'] / 100))} km/h`;
	});


	//------------------FUNKTIONSTASTEN---------------------------//


	for (var j = 0; j < sides.length; j++) {
		var side = sides[j];
		for (var i = 0; i < function_button[side].length; i++) (function(i, side){
			function_button[side][i].onclick = function(){
				if (uid[side] >= 0x4000 || i <= 4) {
					setFn(uid[side], i, !fn_state[side][i]);
				}
				if (uid[side] < 0x4000 && 4 < i && i<= 8) {
					setFn(uid[side] + 1, i - 4, !fn_state[side][i]);
				}
				if (uid[side] < 0x4000 && 8 < i && i <= 12) {
					setFn(uid[side] + 2, i - 8, !fn_state[side][i]);
				}
				if (uid[side] < 0x4000 && 12 < i && i <= 16) {
					setFn(uid[side] + 3, i - 12, !fn_state[side][i]);
				}
				return false;
			};
		})(i, side);
	}

	for (var side in lokliste_toggle) (function(side){
		lokliste_toggle[side].onclick = function(){
			return false;
		};

		lokliste_button[side].onclick = function(){
			if (lokliste_visible[side]) {
				lokliste_container[side].setAttribute('class', 'dropdown');
				lokliste_button[side].setAttribute('class', 'button lokliste')
				lokliste_visible[side] = false;
			} else {
				for (var i = 0; i < uids.length; i++) {
					if (!document.getElementById(`lokliste_option_${side}_${i}`)) {
						createLoklistePoint(i, side);
					}
				}
				lokliste_container[side].setAttribute('class', 'dropdown dropdown_visible');
				lokliste_button[side].setAttribute('class', 'button button_dropdown lokliste')
				lokliste_visible[side] = true;
			}
		}
	})(side);
	

	//--------------------------LOKLISTEN------------------------//



	//---------------------------INITIAL-------------------------//

	ws.onopen = function(){
		getLokliste(true);
	};

	//---------------------------FUNKTIONEN-----------------------------------//

	function loadFn(side){
		for (var i = 0; i < function_button[side].length; i++) {
			if (uid[side] >= 0x4000 || i <= 4) {
				getFn(uid[side], i);
			}
			if (uid[side] < 0x4000 && 4 < i && i <= 8) {
				getFn(uid[side] + 1, i - 4);
			}
			if (uid[side] < 0x4000 && 8 < i && i <= 12) {
				getFn(uid[side] + 2, i - 8);
			}
			if (uid[side] < 0x4000 && 12 < i && i <= 16) {
				getFn(uid[side] + 3, i - 12);
			}
		}
	}

	function updateFn(value, side){
		var fn_num = value >> 8;
		var fn_value = value & 0x00ff;
		if(fn_value){
			function_button[side][fn_num].setAttribute('class', `button function_${side} button_active`);
		}else{
			function_button[side][fn_num].setAttribute('class', `button function_${side}`);
		}
		fn_state[side][fn_num] = fn_value;
		
	}

	function getFn(uid, value){
		send(`getFn:${uid}:${value}`);
	}

	function setFn(uid, fn_num, fn_value){
		var value = (fn_num << 8) + fn_value;
		send(`setFn:${uid}:${value}`);
	}

	function setLok(side, id){
		uid[side] = parseInt(uids[id], 16);
		name_side[side] = names[id].substring(0, 12);
		icon[side] = icons[id];
		if(!vmaxes[id]){
			tachomax[side] = 100;
		} else {
			tachomax[side] = vmaxes[id];
		}
		icon_img[side].setAttribute('src', `icons/${icon[side]}.png`);
		lokliste_button[side].childNodes[1].textContent = name_side[side];
		loadFn(side);
	}

	function getLokliste(initial){
		$.get("php/lokliste.php",{}, function(data){
	    	var str_lokliste = data;
	    	var lokliste = str_lokliste.split("§");
	    	for (var i = lokliste.length - 1; i >= 0; i--) {
	      		names[i] = lokliste[i].split("$")[0];
	      		uids[i] = lokliste[i].split("$")[1];
	      		vmaxes[i] = lokliste[i].split("$")[2];
	      		icons[i] = lokliste[i].split('$')[3];
	    	}
	    	if (initial){
	    		setLok('left', 0);
	    		setLok('right', 1);
		    }
  		});
	}

	function createLoklistePoint(id, side){
		var obj = document.createElement('a');
		var obj_img = document.createElement('img');
		var obj_text = document.createTextNode(names[id].substring(0, 12));
		var obj_div = document.createElement('div');
		obj.setAttribute('href', '');
		obj_img.setAttribute('src', `icons/${icons[id]}.png`);
		obj_div.setAttribute('id', `lokliste_option_${side}_${id}`);
		obj_div.setAttribute('class', 'lokliste_option');
		if (id == 0) {
			obj_div.style.borderTop = 0;
		}
		obj_div.appendChild(obj_img);
		obj_div.appendChild(obj_text);
		obj.appendChild(obj_div);
		lokliste_container[side].appendChild(obj);
		obj_div.onclick = function(){
			setLok(side, id);
			lokliste_container[side].setAttribute('class', 'dropdown');
			lokliste_button[side].setAttribute('class', 'button lokliste')
			lokliste_visible[side] = false;
			return false;
		};
	}

	//------------------------------LISTENER---------------------------------//

	ws.onmessage = function(dgram){
		console.log(`Recieved: ${dgram.data.toString()}.`);
		var msg = dgram.data.toString().split(':');
		var cmd = msg[0];
		var value = parseInt(msg[2])

		if (cmd == 'updateFn') {

			for (var i = 0; i < sides.length; i++) (function(side){
				if ((msg[1] == uid[side] && uid[side] >= 0x4000) || (msg[1] == uid[side] && (value >> 8) <= 4 )) {
					updateFn(value, side);
				}
				if (uid[side] < 0x4000 && msg[1] == uid[side] + 1) {
					updateFn(value + 0x400, side);
				}
				if (uid[side] < 0x4000 && msg[1] == uid[side] + 2) {
					updateFn(value + 0x800, side);
				}
				if (uid[side] < 0x4000 && msg[1] == uid[side] + 3) {
					updateFn(value + 0xc00, side);
				}
			})(sides[i]);
		}
	};

</script>