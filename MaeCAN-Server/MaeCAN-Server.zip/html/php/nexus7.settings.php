<div class="subcontainer">
	<div id="sidebar">
		<a href=""><div class="button button_active">CAN-Geräte</div></a>
		<a href=""><div class="button">Verbrauchswerte</div></a>
	</div>
	<div class="frame_content frame_content_active" id="can-devices">
		<a href=""><div class="button" id="can_dropdown_button" style="width: 296px;">Gerät auswählen</div></a>
		<div id="can_dropdown_container" class="dropdown">
		</div>
		<p>TEST</p>
	</div>
	<div class="frame_content" id="readings">
		<p>Verbrauchswerte</p>
	</div>
</div>

<script type="text/javascript" src="js/websocket.js"></script>
<script type="text/javascript">
	var buttons = document.getElementsByClassName('button');
	var containers = document.getElementsByClassName('frame_content');
	var can_dropdown_button = document.getElementById('can_dropdown_button');
	var can_dropdown_container = document.getElementById('can_dropdown_container');

	dropdown_visible = false;
	
	var deviceList = [];

	for (var i = 0; i < buttons.length; i++) (function(i) {
		buttons[i].onclick = function(){
			for (var j = 0; j < containers.length; j++) {
				containers[j].setAttribute('class', "frame_content");
				buttons[j].setAttribute('class', "button");
			}
			buttons[i].setAttribute('class', 'button button_active');
			containers[i].setAttribute('class', 'frame_content frame_content_active');
			return false;
		}
	})(i);

	function createDropdownPoint(name, uid){
		var obj = document.createElement('a');
		var obj_text = document.createTextNode(name);
		var obj_div = document.createElement('div');
		obj.setAttribute('href', '');
		obj_div.setAttribute('id', uid);
		obj_div.setAttribute('class', 'can_dropdown_option');
		obj_div.appendChild(obj_text);
		obj.appendChild(obj_div);
		can_dropdown_container.appendChild(obj);
	}

	ws.onmessage = function(dgram){
  		var msg = dgram.data.toString().split(':');
		if (msg[0] == 'updateDevices') {
			for (var i = 1; i < msg.length; i = i + 2) {
				if (!document.getElementById(msg[i+1])) {
					createDropdownPoint(msg[i], msg[i+1]);
				}
			}
			if (dropdown_visible) {
				dropdown_visible = false;
				can_dropdown_container.setAttribute('class', 'dropdown')
				can_dropdown_button.setAttribute('class', 'button');
			} else {
				dropdown_visible = true;
				can_dropdown_container.setAttribute('class', 'dropdown dropdown_visible')
				can_dropdown_button.setAttribute('class', 'button button_dropdown');
			}
		}
	};

	can_dropdown_button.onclick = function(){
		send('getDevices');
		return false;
	};
</script>