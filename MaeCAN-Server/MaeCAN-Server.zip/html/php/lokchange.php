<div class="subcontainer">
	<div class="locoselect" id="lokliste">
		<div class="locoselect_left">
			<a href=""><div id="locoselector" style="width: 32.6rem"><img src="./icons/.png" class="lokimg"></img>Lokauswahl</div></a>
		
			<div id="locoselector_list">
					
			</div>
		</div>
	</div>
	<div id="changer">
		<div class="textdiv">
			<p>Name:</p>
			<input class="textfield" type="text" name="name" id="name" value="Name">
		</div>
		<div class="textdiv">
			<p>Adresse:</p>
			<input class="textfield" type="text" name="adrs" id="adrs" value="Adresse">
		</div>
	</div>
</div>
<script type="text/javascript">

var locid = 0;
var vmax = 100;
var icon = '';
var names = [];
var uids = [];
var vmaxes = [];
var icons = [];
var lokliste = [];
var str_lokliste;

var list_visible = false;

var locoselector_list = document.getElementById('locoselector_list');
var locoselector      = document.getElementById('locoselector');

function getLokliste(){
  $.get("php/lokliste.php",{}, function(data){
    //console.log(data);
    str_lokliste = data;
    lokliste = str_lokliste.split("§");
    for (var i = lokliste.length - 1; i >= 0; i--) {
      names[i] = lokliste[i].split("$")[0];
      uids[i] = lokliste[i].split("$")[1];
      vmaxes[i] = lokliste[i].split("$")[2];
      icons[i] = lokliste[i].split('$')[3];
    }
  });
}

function createDropdown(){
  for ( var i = 0; i < lokliste.length; i++) (function(i){
    var obj = document.createElement('a');
    var obj_img = document.createElement('img');
    var obj_text = document.createTextNode(names[i]);
    var obj_div = document.createElement('div');
    obj.setAttribute('href','');
    obj_img.setAttribute('class', 'lokimg');
    obj_img.setAttribute('src', './icons/' + icons[i] + '.png');
    obj_div.setAttribute('class', 'dropdown_point');
    if (true) { obj_div.appendChild(obj_img); }
    obj_div.appendChild(obj_text);
    obj.appendChild(obj_div);
    locoselector_list.appendChild(obj);

    obj.onclick = function(){
      locid = parseInt(uids[i], 16);
      if (vmaxes[i] != ''){
        vmax = parseInt(vmaxes[i]);
      } else {
        vmax = 100;
      }
      icon = icons[i];
      locoselector.childNodes[0].setAttribute('src', './icons/' + icons[i] + '.png');
      locoselector.childNodes[1].textContent = names[i];
      document.getElementById('name').setAttribute('value', names[i]);
      document.getElementById('adrs').setAttribute('value', uids[i]);
      hideDropdown();
      return false;
    };
  })(i);
}

function hideDropdown(){
  var listlength = locoselector_list.childNodes.length;
  for (var i = 0; i < listlength ; i++){
    locoselector_list.removeChild(locoselector_list.childNodes[0]);
  }
  list_visible = false;
}

locoselector.onclick = function(){
  if (!list_visible) {
    getLokliste();
    var timer = setTimeout(function(){
      createDropdown();
    },100);
    list_visible = true
  }else{
    hideDropdown();
  }

  return false;

};

</script>