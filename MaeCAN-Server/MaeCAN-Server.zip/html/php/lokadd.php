<div class="subcontainer" id="lokadd">
	<form>
		<input type="text" name="lokname">
		<input type="text" name="address">
		<div class="radiodiv"><input id="motorola" type="radio" name="protocol"><label for="motorola"><span></span>MM</label></div>
		<div class="radiodiv"><input id="dcc" type="radio" name="protocol"><label for="dcc"><span></span>DCC</label></div>
		<input type="submit" name="confirm">
	</form>
</div>