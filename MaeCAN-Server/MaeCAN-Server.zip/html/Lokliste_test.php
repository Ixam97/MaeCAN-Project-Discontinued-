<div class="dropdown">
  <a href="" id="dropbtn">Dropdown</a>
  <ul id="myDropdown" class="dropdown-content" style="display: block">
  </ul>
</div>


<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript">
var dorpbtn = document.getElementById('dropbtn');
var myDropdown = document.getElementById('myDropdown');
var list_visible = false;
var lokliste = [];
var str_lokliste;
var uids = [];
var names = [];

dropbtn.onclick = function(){
	if (!list_visible) {
		getLokliste();
		var timer = setTimeout(function(){
			createDropdown();
		},10);
		list_visible = true
	}else{
		var listlength = myDropdown.childNodes.length;
		for (var i = 0; i < listlength ; i++){
			console.log('removing ' + i);
			myDropdown.removeChild(myDropdown.childNodes[0]);
		}
		list_visible = false;
	}

	return false;

};

function getLokliste(){
	$.get("php/lokliste.php",{}, function(data){
		//console.log(data);
		str_lokliste = data;
		lokliste = str_lokliste.split("§");
		for (var i = lokliste.length - 1; i >= 0; i--) {
			names[i] = lokliste[i].split("$")[0];
			uids[i] = lokliste[i].split("$")[1];
		}
	});
}

function createDropdown(){
	for ( var i = 0; i < lokliste.length; i++) (function(i){
		var li = document.createElement('li');
		var obj = document.createElement('a');
		var obj_text = document.createTextNode(names[i]);
		obj.setAttribute('class','dorpdown_point');
		obj.setAttribute('href','');
		obj.appendChild(obj_text);
		li.appendChild(obj);
		myDropdown.appendChild(li);

		obj.onclick = function(){
			console.log(uids[i]);
			return false;
		};
	})(i);
}

</script>