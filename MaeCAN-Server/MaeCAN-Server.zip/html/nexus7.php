<!DOCTYPE html>
<html style="font-size: 10px; margin: 0;" id='html'>
	<head>
		<title>MäCAN-Webserver</title>
		<link rel="manifest" href="/nexus7.manifest.json">
		<link rel="shortcut icon" type="image/x-icon" href="/favicon.png">
		<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
		<link rel="stylesheet" type="text/css" href="styles/nexus7.css?<?php echo time()?>">
		<link id="size-stylesheet" rel="stylesheet" type="text/css" href="">
		<meta charset="utf-8">
		<meta name="mobile-web-app-capable" content="yes">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<!--<script type="text/javascript" src="js/jquery.min.js"></script>-->
		<noscript>Javascript ist erforderlich!</noscript>

	</head>
	<body id="body">
		<div id="wrapper">
			<div id="header">
				<a href="https://github.com/Ixam97/MaeCAN-Project"><img id="logo" src="./media/logo.png?1" alt="MäCAN-Server"></a>
				<a href=""><div class="bookmark selected">Loksteuerung</div></a>
				<a href=""><div class="bookmark">Magnetartikel</div></a>
				<a href=""><div class="bookmark">Lokliste bearbeiten</div></a>
				<a href=""><div class="bookmark">Einstellungen</div></a>
				<a href=""><div id="fsicon"><div></div></div></a>
				<p id="time" style="float: right;"></p>
			</div>
			<div id="content">

				<iframe src="./nexus7.integrator.php?page=nexus7.loksteuerung&side=left" id="content_frame"></iframe>
				
			</div>
			<a href=""><div id="stopgo" class="button go">GO</div></a>
			
		</div>

		<script type="text/javascript" src="./js/main.js"></script>
		<script type="text/javascript" src="js/websocket.js?2"></script>
		<script type="text/javascript">
			var bookmarks = document.getElementsByClassName('bookmark');
			var fullscreen = document.getElementById('fsicon');
			var time = document.getElementById('time');
			var content_frame = document.getElementById('content_frame');
			var stopgo = document.getElementById('stopgo');

			var power = false;

			var links = ['./nexus7.integrator.php?page=nexus7.loksteuerung', './nexus7.integrator.php?page=nexus7.memory', './nexus7.integrator.php?page=nexus7.lokchange', './nexus7.integrator.php?page=nexus7.settings'];


			for (var i = 0; i < bookmarks.length; i++) (function(i){
				bookmarks[i].onclick = function(){
					for (var j = 0; j < bookmarks.length; j++) {
						bookmarks[j].setAttribute('class', 'bookmark');
					}
					bookmarks[i].setAttribute('class', 'bookmark selected');
					content_frame.setAttribute('src', links[i]);
					return false;
				};
			})(i);

			fullscreen.onclick = function(){
				toggleFullscreen();
				return false;
			};

			stopgo.onclick = function(){
				if (power) {
					send('stop');
				} else {
					send('go');
				}
				return false;
			};

			setInterval(function(){
				var d = new Date()
				var hours = d.getHours();
				if (hours < 10) { hours = '0' + hours}
				var minutes = d.getMinutes();
				if (minutes < 10) { minutes = '0' + minutes}
				var seconds = d.getSeconds();
				if (seconds < 10) { seconds = '0' + seconds}
				time.innerHTML = hours + ':' + minutes + ':' + seconds;
			}, 1000);

			ws.onmessage = function(dgram){
				var msg = dgram.data.toString().split(':');
				var cmd = msg[0];
				if (cmd == 'go') {
					stopgo.setAttribute('class', 'button stop');
					stopgo.textContent = 'STOP';
					document.getElementById('html').setAttribute('class', 'stop');
					power = true;
				} else if (cmd == 'stop') {
					stopgo.setAttribute('class', 'button go');
					stopgo.textContent = 'GO';
					document.getElementById('html').setAttribute('class', 'go');
					power = false;
				}
			}


		</script>

	</body>
</html>
